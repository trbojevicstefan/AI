# TMDb integration disabled. Placeholder for future enhancements.
